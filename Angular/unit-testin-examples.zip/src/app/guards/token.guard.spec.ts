import { TestBed } from '@angular/core/testing';
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { TokenGuard } from './token.guard';

describe('TokenGuard', () => {
  let guard: TokenGuard;
  let router: Router;
  let navigateSpy: jasmine.Spy;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        TokenGuard,
        { provide: Router, useValue: { navigate: jasmine.createSpy('navigate') } }
      ]
    });

    guard = TestBed.inject(TokenGuard);
    router = TestBed.inject(Router);
    navigateSpy = router.navigate as jasmine.Spy;
  });

  it('should allow the route when token is present', () => {
    spyOn(localStorage, 'getItem').and.returnValue('some-token');

    const route = {} as ActivatedRouteSnapshot;
    const state = { url: '/some-url' } as RouterStateSnapshot;
    const result = guard.canActivate(route, state);

    expect(result).toBeTrue();
    expect(navigateSpy).not.toHaveBeenCalled();
  });

  it('should redirect to login when token is absent', () => {
    spyOn(localStorage, 'getItem').and.returnValue(null);

    const route = {} as ActivatedRouteSnapshot;
    const state = { url: '/some-url' } as RouterStateSnapshot;
    const result = guard.canActivate(route, state);

    expect(result).toBeFalse();
    expect(navigateSpy).toHaveBeenCalledWith(['/login'], { queryParams: { returnurl: '/some-url' } });
  });
});
