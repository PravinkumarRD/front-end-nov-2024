import { Component, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'bajaj-station-search',
  standalone: false,

  templateUrl: './station-search.component.html',
  styleUrl: './station-search.component.scss'
})
export class StationSearchComponent {
  @Input() target: string = '';
  @Output() citySelected = new EventEmitter<string>();
  @Output() cancel = new EventEmitter<void>();
  searchText: string = '';
  popularCities: string[] = ['New Delhi', 'Mumbai', 'Chennai', 'Kolkata', 'Bengaluru'];
  filteredCities: string[] = [];
  selectedCity: string = '';
  ngOnInit(): void {
    this.filteredCities = this.popularCities;
  }
  filterCities(): void {
    this.filteredCities = this.popularCities.filter(city => city.toLowerCase().includes(this.searchText.toLowerCase()));
  }
  selectCity(city: string): void {
    this.selectedCity = city;
    this.filteredCities = [];
  }
  setSearchText(city: string): void { this.searchText = city; this.filteredCities = this.popularCities.filter(c => c.toLowerCase().includes(city.toLowerCase()) ); }
  goBack(): void {
    if (this.selectedCity) {
      this.citySelected.emit(this.selectedCity);
    } else {
      this.cancel.emit();
    }
  }
}
