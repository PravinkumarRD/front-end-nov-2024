const EVENTS_LIST_TITLE = "Welcome To Bajaj Events List! Bangalore!";
const EVENTS_LIST_SUB_TITLE = "Published By Global Hr Team! Pune!";

const TABLE_COLUMNS: string[] = ["Event Code", "Event Name", "Start Date", "Fees","Show Details"];

const EVENT_DETAILS_TITLE = "Detail Of - ";

export { EVENTS_LIST_TITLE, EVENTS_LIST_SUB_TITLE, TABLE_COLUMNS, EVENT_DETAILS_TITLE }