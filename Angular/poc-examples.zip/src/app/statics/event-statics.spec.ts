import { EventStatics } from './event-statics';

describe('EventStatics', () => {
  it('should create an instance', () => {
    expect(new EventStatics()).toBeTruthy();
  });
});
