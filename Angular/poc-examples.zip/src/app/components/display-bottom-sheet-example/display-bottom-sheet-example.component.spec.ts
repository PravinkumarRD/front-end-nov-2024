import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayBottomSheetExampleComponent } from './display-bottom-sheet-example.component';

describe('DisplayBottomSheetExampleComponent', () => {
  let component: DisplayBottomSheetExampleComponent;
  let fixture: ComponentFixture<DisplayBottomSheetExampleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DisplayBottomSheetExampleComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DisplayBottomSheetExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
