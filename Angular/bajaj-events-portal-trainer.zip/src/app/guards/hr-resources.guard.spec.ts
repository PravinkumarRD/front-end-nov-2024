import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { hrResourcesGuard } from './hr-resources.guard';

describe('hrResourcesGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => hrResourcesGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
