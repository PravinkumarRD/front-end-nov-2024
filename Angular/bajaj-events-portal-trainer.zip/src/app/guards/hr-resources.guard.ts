import { CanActivateFn, Router } from '@angular/router';
import { inject } from "@angular/core";

export const hrResourcesGuard: CanActivateFn = (route, state) => {
  let role = localStorage.getItem("role");
  console.log(role)
  const _router = inject(Router);
  if (role === "Hr") {
    return true;
  } else {
    _router.navigate(['/access-denied']);
    return false;
  }
};
