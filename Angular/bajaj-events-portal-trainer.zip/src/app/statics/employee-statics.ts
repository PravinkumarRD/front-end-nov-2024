export const EMPLOYEES_LIST_TITLE = "Welcome To Bajaj Employees List! Bangalore!";
export const EMPLOYEES_LIST_SUB_TITLE = "Core Development Members!";

export const TABLE_COLUMNS: string[] = ["Employee Name", "City", "Email", "Contact #", "Show Details"];

export const EMPLOYEE_DETAILS_TITLE = "Details Of - ";

