import { TestBed } from '@angular/core/testing';
import { EventsService } from './events.service';
import { Event } from '../models/event';


describe('EventsService', () => {
  let service: EventsService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers:[
        EventsService
      ]
    });
    service = TestBed.inject(EventsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return all events', () => {
    const events: Event[] = service.getAllEvents();
    expect(events.length).toBe(5);

    expect(events[0].eventCode).toBe('SEMJQ3');
    expect(events[0].eventName).toBe('Seminar on jQuery 3.x');
    expect(events[0].fees).toBe(800);

    expect(events[1].eventCode).toBe('SEMNG1');
    expect(events[1].eventName).toBe('Seminar on Angular JS 1.5.x');
    expect(events[1].fees).toBe(600);

    expect(events[2].eventCode).toBe('SEMNG2');
    expect(events[2].eventName).toBe('Seminar on Angular 2.x');
    expect(events[2].fees).toBe(1000);

    expect(events[3].eventCode).toBe('SEMNG4');
    expect(events[3].eventName).toBe('Seminar on Angular 4.x');
    expect(events[3].fees).toBe(1000);

    expect(events[4].eventCode).toBe('SEMBS3');
    expect(events[4].eventName).toBe('Seminar on Bootstrap 3.x');
    expect(events[4].fees).toBe(500);
  });
});

