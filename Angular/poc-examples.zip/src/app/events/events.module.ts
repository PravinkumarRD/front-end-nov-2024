import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatBottomSheetModule } from '@angular/material/bottom-sheet';

import { EventsListComponent } from './components/events-list/events-list.component';
import { EventDetailsComponent } from './components/event-details/event-details.component';
import { DisclaimerComponent } from './components/disclaimer/disclaimer.component';



@NgModule({
  declarations: [
    EventsListComponent,
    EventDetailsComponent,
    DisclaimerComponent
  ],
  imports: [
    CommonModule,
    MatBottomSheetModule
  ],
  exports:[
    EventsListComponent
  ]
})
export class EventsModule { }
