import { HighlighterDirective } from './highlighter.directive';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Renderer2 } from '@angular/core';
import { EventsListComponent } from '../../events/components/events-list/events-list.component';
import { EventsService } from '../../events/services/events.service';

describe('HighlighterDirective', () => {
  let fixture: ComponentFixture<EventsListComponent>;
  let renderer2: Renderer2;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EventsListComponent, HighlighterDirective],
      providers: [Renderer2,EventsService] 
    });

    fixture = TestBed.createComponent(EventsListComponent);
    renderer2 = fixture.componentRef.injector.get(Renderer2);
    fixture.detectChanges();
  });

  it('should create an instance of the directive', () => {
    const directiveInstance = new HighlighterDirective(fixture.debugElement.query(By.css('div')).nativeElement, renderer2);
    expect(directiveInstance).toBeTruthy();
  });

  it('should apply transform style on mouse enter', () => {
    const debugElement = fixture.debugElement.query(By.css('h1'));

    debugElement.triggerEventHandler('mouseenter', null);
    fixture.detectChanges();

    expect(debugElement.nativeElement.style.transform).toBe('skewY(-10deg) scale(1.5)');
    expect(debugElement.nativeElement.style.transition).toBe('transform 0.5s ease-in-out');
  });

  it('should remove transform style on mouse leave', () => {
    const debugElement = fixture.debugElement.query(By.css('h1'));

    debugElement.triggerEventHandler('mouseleave', null);
    fixture.detectChanges();

    expect(debugElement.nativeElement.style.transform).toBe('skewY(0deg)');
    expect(debugElement.nativeElement.style.transition).toBe('transform 0.5s ease-in-out');
  });
});
