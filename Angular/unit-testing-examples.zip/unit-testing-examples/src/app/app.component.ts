import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  standalone: false,
  styleUrl: './app.component.scss'
})
export class AppComponent {
  pageTitle:string='Welcome To Bajaj Finserv!';
  
  onClick() {
    console.log('Button clicked');
  }
}
