import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { EmployeesService } from './employees.service';
import { Employee } from '../models/employee';

describe('EmployeesService', () => {
  let service: EmployeesService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [EmployeesService]
    });

    service = TestBed.inject(EmployeesService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch all employees', () => {
    const dummyEmployees: Employee[] = [
      {
        employeeId: 2370,
        employeeName: "Pravinkumar R. D.",
        address: "Suncity, A8/404",
        city: "Pune",
        zipcode: 411051,
        phone: "+91 23892893",
        email: "pravin.r.d@synechron.com",
        skillSets: "Microsoft/JavaScript",
        country: "India",
        joiningDate:new Date(),
        avatar: "images/noimage.png"
    },
    {
        employeeId: 2372,
        employeeName: "Manish Kaushik",
        address: "Mooncity, Z8/404",
        city: "Raipur",
        zipcode: 459899,
        phone: "+91 9039039090",
        email: "manish.kaushik@synechron.com",
        skillSets: "DBA",
        country: "India",
        joiningDate:new Date(),
        avatar: "images/noimage.png"
    }
    ];

    service.getAllEmployees().subscribe(employees => {
      expect(employees.length).toBe(2);
      expect(employees).toEqual(dummyEmployees);
    });

    const req = httpMock.expectOne('http://localhost:3000/employees');
    expect(req.request.method).toBe('GET');
    req.flush(dummyEmployees);
  });

  it('should fetch employee details by id', () => {
    const dummyEmployee: Employee = {
      employeeId: 2372,
      employeeName: "Manish Kaushik",
      address: "Mooncity, Z8/404",
      city: "Raipur",
      zipcode: 459899,
      phone: "+91 9039039090",
      email: "manish.kaushik@synechron.com",
      skillSets: "DBA",
      country: "India",
      joiningDate:new Date(),
      avatar: "images/noimage.png"
  };

    service.getEmployeeDetails(1).subscribe(employee => {
      expect(employee).toEqual(dummyEmployee);
    });

    const req = httpMock.expectOne('http://localhost:3000/employees/1');
    expect(req.request.method).toBe('GET');
    req.flush(dummyEmployee);
  });
});
