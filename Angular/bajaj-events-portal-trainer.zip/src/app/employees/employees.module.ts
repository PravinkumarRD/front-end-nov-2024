import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { EmployeesRoutingModule } from './employees-routing.module';

import { EmployeesListComponent } from './components/employees-list/employees-list.component';
import { EmployeeDetailsComponent } from './components/employee-details/employee-details.component';


import { BajajEmployeesService } from './services/bajaj-employees.service';




@NgModule({
  declarations: [
    EmployeesListComponent,
    EmployeeDetailsComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    EmployeesRoutingModule
  ],
  exports: [
    EmployeesListComponent
  ],
  providers:[BajajEmployeesService]
})
export class EmployeesModule { }
