// import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from "@angular/router";
import { Subscription } from "rxjs";

import { Event } from "../../models/event";

import { EVENT_DETAILS_TITLE, DETAILS_TABLE_COLUMNS } from "../../../statics/event-statics";

import { BajajEventsService } from "../../services/bajaj-events.service";

@Component({
  selector: 'bajaj-event-details',
  standalone: false,
  templateUrl: './event-details.component.html',
  styleUrl: './event-details.component.scss'
})
export class EventDetailsComponent implements OnInit, OnDestroy {

  constructor(private _activatedRoute: ActivatedRoute, private _eventsService: BajajEventsService) {

  }

  private _eventsServiceSubscription: Subscription;
  pageTitle: string = EVENT_DETAILS_TITLE;
  // @Input() eventId: number;
  event?: Event;
  columns: string[] = DETAILS_TABLE_COLUMNS;

  ngOnInit(): void {
    let eventId = this._activatedRoute.snapshot.params['id'];
   this._eventsServiceSubscription = this._eventsService.getEventDetails(eventId).subscribe({
      next: data => this.event = data,
      error: err => console.log(err)
    });
  }
  ngOnDestroy(): void {
    if(this._eventsServiceSubscription){
      this._eventsServiceSubscription.unsubscribe()
      console.log('EventDetails Observable has been unsubscribed!');
    }
      
  }
}
