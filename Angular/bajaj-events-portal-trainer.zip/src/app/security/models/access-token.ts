export class AccessToken {
    email:string;
    token:string;
    role:string;
}
