import { Component, Input, EventEmitter, Output } from '@angular/core';

import { EMPLOYEE_DETAILS_TITLE } from "../../../statics/employee-statics";

import { Employee } from "../../models/employee";

@Component({
  selector: 'app-employee-details',
  standalone: false,
  templateUrl: './employee-details.component.html',
  styleUrl: './employee-details.component.scss'
})
export class EmployeeDetailsComponent {
  pageTitle: string = EMPLOYEE_DETAILS_TITLE;
  @Input() employee: Employee;
  @Output() sendMessage: EventEmitter<string> = new EventEmitter<string>();
  onMessageSend():void{
    this.sendMessage.emit(`Employee ${this.employee.employeeName} has been selected for project interview of HSBC!`);
  }
}
