import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from "@angular/common/http";
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { EventsRoutingModule } from './events-routing.module';

import { EventsListComponent } from './components/events-list/events-list.component';
import { EventDetailsComponent } from './components/event-details/event-details.component';

import { SharedModule } from '../shared/shared.module';

import { BajajEventsService } from './services/bajaj-events.service';



@NgModule({
  declarations: [
    EventsListComponent,
    EventDetailsComponent
  ],
  providers:[
    BajajEventsService
  ],
  imports: [
    EventsRoutingModule,
    CommonModule,
    FormsModule,
    HttpClientModule,
    SharedModule,
    RouterModule
  ],
  exports:[
    EventsListComponent
  ]
})
export class EventsModule { }
