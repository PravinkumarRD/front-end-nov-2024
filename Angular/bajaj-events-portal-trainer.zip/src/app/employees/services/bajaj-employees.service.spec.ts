import { TestBed } from '@angular/core/testing';

import { BajajEmployeesService } from './bajaj-employees.service';

describe('BajajEmployeesService', () => {
  let service: BajajEmployeesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BajajEmployeesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
