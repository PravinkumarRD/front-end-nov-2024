import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EventsListComponent } from './events-list.component';

import { Event } from "../../models/event";

//First Test
/*describe('EventsListComponent', () => {
  let component: EventsListComponent;
  let fixture: ComponentFixture<EventsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EventsListComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EventsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it(`should have page title as 'Welcome To Bajaj Finserv Events!'`,()=>{
    expect(component.pageTitle).toEqual("Welcome To Bajaj Finserv Events!");
  })
});*/

//Second Test Case
/*describe('EventsListComponent', () => {
  let component: EventsListComponent;
  let fixture: ComponentFixture<EventsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EventsListComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(EventsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });
  it(`should have page title as 'Welcome To Bajaj Finserv Events!'`, () => {
    expect(component.pageTitle).toEqual("Welcome To Bajaj Finserv Events!");
  });
  it(`should have page sub title as 'Published By Hr of Bajaj!'`, () => {
    expect(component.pageSubTitle).toEqual("Published By Hr of Bajaj!");
  });
  it('should initialize events correctly', () => { 
    expect(component.events.length).toBe(5); 
    expect(component.events[0].eventCode).toBe('SEMJQ3'); 
    expect(component.events[1].eventCode).toBe('SEMNG1'); 
    expect(component.events[2].eventCode).toBe('SEMNG2'); 
    expect(component.events[3].eventCode).toBe('SEMNG4'); 
    expect(component.events[4].eventCode).toBe('SEMBS3'); 
  });
});
*/
//Third Test Case
/*describe('EventsListComponent', () => {
  let component: EventsListComponent;
  let fixture: ComponentFixture<EventsListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EventsListComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(EventsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create component', () => {
    expect(component).toBeTruthy();
  });
  it(`should have page title as 'Welcome To Bajaj Finserv Events!'`, () => {
    expect(component.pageTitle).toEqual("Welcome To Bajaj Finserv Events!");
  });
  it(`should have page sub title as 'Published By Hr of Bajaj!'`, () => {
    expect(component.pageSubTitle).toEqual("Published By Hr of Bajaj!");
  });

  it('should initialize events correctly', () => {
    expect(component.events.length).toBe(5);
    expect(component.events[0].eventCode).toBe('SEMJQ3');
    expect(component.events[1].eventCode).toBe('SEMNG1');
    expect(component.events[2].eventCode).toBe('SEMNG2');
    expect(component.events[3].eventCode).toBe('SEMNG4');
    expect(component.events[4].eventCode).toBe('SEMBS3');
  });

  it('should select an event on onEventSelection', () => {
    const event: Event =
    {
      eventId: 1006,
      eventCode: 'SEMTES',
      eventName: 'Test Event',
      description: 'A Test Event for Unit Testing', 
      startDate: new Date(), 
      endDate: new Date(), 
      fees: 0, 
      seatsFilled: 0, 
      logo: 'assets/images/noimage.png'
    }; 
    component.onEventSelection(event); 
    expect(component.selectedEvent).toBe(event);
  });
});
*/
//Forth Test Case - Testing Component Template
/*import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { DatePipe } from '@angular/common';
describe('EventsListComponent', () => {
  let component: EventsListComponent;
  let fixture: ComponentFixture<EventsListComponent>;
  let debugElement: DebugElement;
  let datePipe: DatePipe;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EventsListComponent],
      providers: [DatePipe]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EventsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    datePipe = TestBed.inject(DatePipe);
    debugElement = fixture.debugElement;
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should display the page title', () => {
    const titleElement: HTMLElement = debugElement.query(By.css('h1')).nativeElement;
    expect(titleElement.textContent).toBe(component.pageTitle);
  });

  it('should display the page subtitle', () => {
    const subTitleElement: HTMLElement = debugElement.query(By.css('h6')).nativeElement;
    expect(subTitleElement.textContent).toBe(component.pageSubTitle);
  });

  it('should display the correct number of columns', () => {
    const columnElements = debugElement.queryAll(By.css('thead th'));
    expect(columnElements.length).toBe(component.columns.length);
  });

  it('should display the list of events in the table', () => {
    const eventRows = debugElement.queryAll(By.css('tbody tr'));
    expect(eventRows.length).toBe(component.events.length);

    const firstEvent = eventRows[0].nativeElement;
    expect(firstEvent.textContent).toContain(component.events[0].eventCode.toLowerCase());
    expect(firstEvent.textContent).toContain(component.events[0].eventName.toUpperCase());
    const formattedDate = datePipe.transform(component.events[0].startDate, 'dd-MMMM-yyyy'); expect(firstEvent.textContent).toContain(formattedDate);
    expect(firstEvent.textContent).toContain(`₹${component.events[0].fees.toFixed(2)}`);
  });

  it('should call onEventSelection when the "Show Details" button is clicked', () => {
    spyOn(component, 'onEventSelection');
    
    const buttonElement = debugElement.query(By.css('tbody tr button')).nativeElement;
    buttonElement.click();
    
    fixture.detectChanges();

    expect(component.onEventSelection).toHaveBeenCalledWith(component.events[0]);
  });

  it('should display the noDataTemplate when no events are present', () => {
    component.events = [];
    fixture.detectChanges();

    const noDataElement: HTMLElement = debugElement.query(By.css('.container h3')).nativeElement;
    expect(noDataElement.textContent).toBe('Sorry! We did not find any events! Please try after some time!');
  });
});
*/
//Fifth Test with Dependency Injection
import { EventsService } from '../../services/events.service';
import { By } from '@angular/platform-browser';
//MockService
class MockEventsService {
  private _events: Event[] = [
    {
      eventId: 1001,
      eventCode: 'SEMJQ3',
      eventName: 'Seminar on jQuery 3.x',
      description: 'Seminar will discuss all the new features of jQuery 3.x',
      startDate: new Date(),
      endDate: new Date(),
      fees: 800,
      seatsFilled: 70,
      logo: 'assets/images/jq3.png'
    },
    {
      eventId: 1002,
      eventCode: 'SEMNG1',
      eventName: 'Seminar on Angular JS 1.5.x',
      description: 'Seminar will discuss all the new features of Angular JS 1.5.x',
      startDate: new Date(),
      endDate: new Date(),
      fees: 600,
      seatsFilled: 50,
      logo: 'assets/images/ng1.png'
    },
    {
      eventId: 1003,
      eventCode: 'SEMNG2',
      eventName: 'Seminar on Angular 2.x',
      description: 'Seminar will discuss all the new features of Angular 2.x',
      startDate: new Date(),
      endDate: new Date(),
      fees: 1000,
      seatsFilled: 80,
      logo: 'assets/images/ng2.png'
    },
    {
      eventId: 1004,
      eventCode: 'SEMNG4',
      eventName: 'Seminar on Angular 4.x',
      description: 'Seminar will discuss all the new features of Angular 4.x',
      startDate: new Date(),
      endDate: new Date(),
      fees: 1000,
      seatsFilled: 76,
      logo: 'assets/images/ng2.png'
    },
    {
      eventId: 1005,
      eventCode: 'SEMBS3',
      eventName: 'Seminar on Bootstrap 3.x',
      description: 'Seminar will discuss all the new features of Bootstrap 3.x',
      startDate: new Date(),
      endDate: new Date(),
      fees: 500,
      seatsFilled: 34,
      logo: 'assets/images/bs3.png'
    }
  ];

  getAllEvents(): Event[] {
    return this._events;
  }
}

//Component
describe('EventsListComponent', () => {
  let component: EventsListComponent;
  let fixture: ComponentFixture<EventsListComponent>;
  let eventsService: EventsService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EventsListComponent],
      providers: [{ provide: EventsService, useClass: MockEventsService }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EventsListComponent);
    component = fixture.componentInstance;
    eventsService = TestBed.inject(EventsService);
    fixture.detectChanges();
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize events from the service', () => {
    component.ngOnInit();
    expect(component.events.length).toBe(5);
    expect(component.events[0].eventCode).toBe('SEMJQ3');
    expect(component.events[1].eventCode).toBe('SEMNG1');
    expect(component.events[2].eventCode).toBe('SEMNG2');
    expect(component.events[3].eventCode).toBe('SEMNG4');
    expect(component.events[4].eventCode).toBe('SEMBS3');
  });

  it('should set selectedEvent on onEventSelection', () => {
    const event: Event = {
      eventId: 1006,
      eventCode: 'SEMTES',
      eventName: 'Test Event',
      description: 'A Test Event for Unit Testing',
      startDate: new Date(),
      endDate: new Date(),
      fees: 0,
      seatsFilled: 0,
      logo: 'assets/images/test.png'
    };

    component.onEventSelection(event);
    expect(component.selectedEvent).toBe(event);
  });

  it('should display the page title', () => {
    const titleElement: HTMLElement = fixture.debugElement.query(By.css('h1')).nativeElement;
    expect(titleElement.textContent).toBe(component.pageTitle);
  });

  it('should display the page subtitle', () => {
    const subTitleElement: HTMLElement = fixture.debugElement.query(By.css('h6')).nativeElement;
    expect(subTitleElement.textContent).toBe(component.pageSubTitle);
  });
});

