import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { EmployeesService } from './employees.service';
import { Employee } from '../models/employee';
import { CustomHeaderInterceptor } from './custom-header.interceptor';  

describe('EmployeesService', () => {
  let service: EmployeesService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule], 
      providers: [
        EmployeesService,
        { provide: HTTP_INTERCEPTORS, useClass: CustomHeaderInterceptor, multi: true }
      ]
    });

    service = TestBed.inject(EmployeesService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  afterEach(() => {
    httpMock.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should fetch all employees with interceptor', () => {
    const dummyEmployees: Employee[] = [
      {
        employeeId: 1,
        employeeName: 'John Doe',
        address: '123 Main St',
        city: 'New York',
        zipcode: 10001,
        phone: '123-456-7890',
        email: 'john.doe@example.com',
        avatar: 'avatar1.png',
        country: 'USA',
        joiningDate: new Date('2020-01-01'),
        skillSets: 'JavaScript, Angular'
      },
      {
        employeeId: 2,
        employeeName: 'Jane Smith',
        address: '456 Elm St',
        city: 'San Francisco',
        zipcode: 94101,
        phone: '987-654-3210',
        email: 'jane.smith@example.com',
        avatar: 'avatar2.png',
        country: 'USA',
        joiningDate: new Date('2019-03-15'),
        skillSets: 'Java, Spring'
      }
    ];

    service.getAllEmployees().subscribe(employees => {
      expect(employees.length).toBe(2);
      expect(employees).toEqual(dummyEmployees);
    });

    const req = httpMock.expectOne('http://localhost:3000/employees');
    expect(req.request.method).toBe('GET');
    expect(req.request.headers.has('X-Bajaj-Authorization')).toBe(true);
    expect(req.request.headers.get('X-Bajaj-Authorization')).toBe('Authorization-Token');
    req.flush(dummyEmployees);
  });

  it('should fetch employee details by employeeId with interceptor', () => {
    const dummyEmployee: Employee = {
      employeeId: 1,
      employeeName: 'John Doe',
      address: '123 Main St',
      city: 'New York',
      zipcode: 10001,
      phone: '123-456-7890',
      email: 'john.doe@example.com',
      avatar: 'avatar1.png',
      country: 'USA',
      joiningDate: new Date('2020-01-01'),
      skillSets: 'JavaScript, Angular'
    };

    service.getEmployeeDetails(1).subscribe(employee => {
      expect(employee).toEqual(dummyEmployee);
    });

    const req = httpMock.expectOne('http://localhost:3000/employees/1');
    expect(req.request.method).toBe('GET');
    expect(req.request.headers.has('X-Bajaj-Authorization')).toBe(true);
    expect(req.request.headers.get('X-Bajaj-Authorization')).toBe('Authorization-Token');
    req.flush(dummyEmployee);
  });
});
