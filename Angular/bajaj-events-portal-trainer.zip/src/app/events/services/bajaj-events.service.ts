import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

import { Event } from "../models/event";
import { bs3Logo, jQueryLogo, ng1Logo, ng2Logo } from "../../statics/image-urls";

@Injectable()
export class BajajEventsService {

  constructor(private _httpClient: HttpClient) {

  }

  getAllEvents(): Observable<Event[]> {
    return this._httpClient.get<Event[]>(`http://localhost:9090/api/events`);
  }
  getEventDetails(eventId: number): Observable<Event> {
    return this._httpClient.get<Event>(`http://localhost:9090/api/events/${eventId}`);
  }
  registerNewEvent(event: Event): Observable<any> {
    event.logo = "assets/images/noimage.png";
    return this._httpClient.post<any>('http://localhost:9090/api/events', event);
  }
}

// @Injectable({
//   providedIn: 'root'
// })
// @Injectable()
// export class BajajEventsService {
//   private _eventsData: Event[] = [
//     {
//       eventId: 1001,
//       eventCode: 'SEMJQ3',
//       eventName: 'Seminar on jQuery 3.x',
//       description: 'Seminar will discuss all the new features of jQuery 3.x',
//       startDate: new Date(),
//       endDate: new Date(),
//       fees: 800,
//       seatsFilled: 70,
//       logo: jQueryLogo
//     },
//     {
//       eventId: 1002,
//       eventCode: 'SEMNG1',
//       eventName: 'Seminar on Angular JS 1.5.x',
//       description: 'Seminar will discuss all the new features of Angular JS 1.5.x',
//       startDate: new Date(),
//       endDate: new Date(),
//       fees: 600,
//       seatsFilled: 50,
//       logo: ng1Logo
//     },
//     {
//       eventId: 1003,
//       eventCode: 'SEMNG2',
//       eventName: 'Seminar on Angular 2.x',
//       description: 'Seminar will discuss all the new features of Angular 2.x',
//       startDate: new Date(),
//       endDate: new Date(),
//       fees: 1000,
//       seatsFilled: 80,
//       logo: ng2Logo
//     },
//     {
//       eventId: 1004,
//       eventCode: 'SEMNG4',
//       eventName: 'Seminar on Angular 4.x',
//       description: 'Seminar will discuss all the new features of Angular 4.x',
//       startDate: new Date(),
//       endDate: new Date(),
//       fees: 1000,
//       seatsFilled: 76,
//       logo: ng2Logo
//     },
//     {
//       eventId: 1005,
//       eventCode: 'SEMBS3',
//       eventName: 'Seminar on Bootstrap 3.x',
//       description: 'Seminar will discuss all the new features of Bootstrap 3.x',
//       startDate: new Date(),
//       endDate: new Date(),
//       fees: 500,
//       seatsFilled: 34,
//       logo: bs3Logo
//     }
//   ];
//   getAllEvents(): Event[] {
//     return this._eventsData;
//   }
//   getEventDetails(eventId: number): Event | undefined {
//     return this._eventsData.find(event => event.eventId === eventId);
//   }
// }
