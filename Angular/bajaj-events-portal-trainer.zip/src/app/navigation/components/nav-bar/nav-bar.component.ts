import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

@Component({
  selector: 'bajaj-nav-bar',
  standalone: false,

  templateUrl: './nav-bar.component.html',
  styleUrl: './nav-bar.component.scss'
})
export class NavBarComponent implements OnInit {
  constructor(private _router: Router) {

  }
  token: string | null;
  role: string | null;
  ngOnInit(): void {
    this._router.events.subscribe({
      next: data => {
        this.token = localStorage.getItem('token');
        this.role = localStorage.getItem('role');
      }
    });
  }
  onSignOut(): void {
    localStorage.clear();
  }
}
