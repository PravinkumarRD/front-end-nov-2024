import { BajajEvent } from './bajaj-event';

describe('BajajEvent', () => {
  it('should create an instance', () => {
    expect(new BajajEvent()).toBeTruthy();
  });
});
