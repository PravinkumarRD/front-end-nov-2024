import { Component } from '@angular/core';

@Component({
  selector: 'bajaj-home',
  standalone: false,
  
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent {

}
