import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from "rxjs";

import { Event } from "../../models/event";

import { EVENTS_LIST_TITLE, EVENTS_LIST_SUB_TITLE, TABLE_COLUMNS } from "../../../statics/event-statics";

import { BajajEventsService } from "../../services/bajaj-events.service";

@Component({
  selector: 'bajaj-events-list',
  templateUrl: './events-list.component.html',
  styleUrl: './events-list.component.scss',
  standalone: false
})
export class EventsListComponent implements OnInit, OnDestroy {
  constructor(private _eventsService: BajajEventsService) {

  }

  private _eventsServiceSubscription: Subscription;
  pageTitle: string = EVENTS_LIST_TITLE;
  pageSubTitle: string = EVENTS_LIST_SUB_TITLE;
  columns: string[] = TABLE_COLUMNS;
  events: Event[] = [];
  filteredEvents: Event[];
  //selectedEvent: Event;
  //selectedEventId: number;
  searchCharacters: string = '';

  ngOnInit(): void {
    this._eventsServiceSubscription = this._eventsService.getAllEvents().subscribe({
      next: data => {
        this.events = data;
        console.log(this.events)
        this.filteredEvents = this.events;
      }
    });
  }
  // onEventSelection(eventId: number): void {
  //   this.selectedEventId = eventId;
  //   console.log(this.selectedEventId)
  // }
  searchEvents(): void {
    if (!this.searchCharacters || this.searchCharacters == '') {
      this.filteredEvents = this.events;
    } else {
      this.filteredEvents = this.events.filter(event => event.eventName.toLocaleLowerCase().includes(this.searchCharacters.toLocaleLowerCase()));
    }
  }
  ngOnDestroy(): void {
    if (this._eventsServiceSubscription) {
      this._eventsServiceSubscription.unsubscribe()
      console.log('EventsList Observable has been unsubscribed!');
    }
  }
}
