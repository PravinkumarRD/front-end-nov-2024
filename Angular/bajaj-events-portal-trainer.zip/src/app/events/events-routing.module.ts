import { NgModule } from '@angular/core';
import { RouterModule, Routes } from "@angular/router";

import { EventsListComponent } from './components/events-list/events-list.component';
import { EventDetailsComponent } from './components/event-details/event-details.component';

import { tokenGuard } from '../guards/token.guard';

//Children Routes []
const routes: Routes = [
  {
    path: '',
    component: EventsListComponent,
    title: 'Events List',
    canActivate: [tokenGuard]
  },
  {
    path: ':id',
    component: EventDetailsComponent,
    title: 'Event Details',
    canActivate: [tokenGuard]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class EventsRoutingModule { }
