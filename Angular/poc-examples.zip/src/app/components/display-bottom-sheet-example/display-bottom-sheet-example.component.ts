import { Component } from '@angular/core';
import { MatBottomSheet } from '@angular/material/bottom-sheet';

import { DisclaimerComponent } from '../../events/components/disclaimer/disclaimer.component';

@Component({
  selector: 'bajaj-display-bottom-sheet-example',
  standalone: false,

  templateUrl: './display-bottom-sheet-example.component.html',
  styleUrl: './display-bottom-sheet-example.component.scss'
})
export class DisplayBottomSheetExampleComponent {
  constructor(private bottomSheet: MatBottomSheet) {

  }
  openBottomSheet(): void {
    const ref = this.bottomSheet.open(DisclaimerComponent);
    ref.afterDismissed().subscribe(result => {
      if (result) {
        // Handle the sorting and filtering logic here 
        console.log('Sorting:', result.sort);
        console.log('Filtering:', result.filter);
      }
    });
  }
}
