import { MultiLingualDatePipe } from './multi-lingual-date.pipe';

describe('MultiLingualDatePipe', () => {
  let pipe: MultiLingualDatePipe;

  beforeEach(() => {
    pipe = new MultiLingualDatePipe();
  });

  it('should create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('should format date in default locale (en-IN)', () => {
    const date = new Date('2023-04-08T14:00:00Z');
    const formattedDate = pipe.transform(date);
    expect(formattedDate).toBe('Saturday 08 April, 2023 at 07:30:00 pm'); 
  });

  it('should format date in provided locale (fr-FR)', () => {
    const date = new Date('2023-04-08T14:00:00Z');
    const formattedDate = pipe.transform(date, 'fr-FR');
    expect(formattedDate).toBe('samedi 08 avril 2023 à 07:30:00 PM'); 
  });
  //Failure Test Case
  /*it('should handle invalid date input', () => {
    const formattedDate = pipe.transform(new Date('invalid date'));
    expect(formattedDate).toBe('');
  });*/
});
