import { Component, OnDestroy } from '@angular/core';
import { Router } from "@angular/router";
import { Subscription } from "rxjs";

import { BajajEventsService } from "../../services/bajaj-events.service";

import { BajajEvent } from "../../models/bajaj-event";

@Component({
  selector: 'bajaj-register-event',
  standalone: false,

  templateUrl: './register-event.component.html',
  styleUrl: './register-event.component.scss'
})
export class RegisterEventComponent implements OnDestroy {
  constructor(private _eventsService: BajajEventsService, private _router: Router) {

  }

  private _eventsServiceSubscription: Subscription;
  pageTitle: string = "Bajaj Event Registration Form!";
  bajajEvent: BajajEvent = new BajajEvent();

  onEventSubmit(): void {
    this._eventsServiceSubscription = this._eventsService.registerNewEvent(this.bajajEvent.registrationForm.value).subscribe({
      next: data => {
        if (data?.['acknowledged'] === true) {
          this._router.navigate(['/events']);
        }
      }
    });
  }
  ngOnDestroy(): void {
    if (this._eventsServiceSubscription) {
      this._eventsServiceSubscription.unsubscribe();
    }
  }
}
