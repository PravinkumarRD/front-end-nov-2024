import { Component } from '@angular/core';
import { MatBottomSheetRef } from '@angular/material/bottom-sheet'

@Component({
  selector: 'bajaj-disclaimer',
  standalone: false,

  templateUrl: './disclaimer.component.html',
  styleUrl: './disclaimer.component.scss'
})
export class DisclaimerComponent {
  selectedTab: string = 'sort';
  sortOption: string = '';
  filterOption: string = '';
  constructor(private bottomSheetRef: MatBottomSheetRef<DisclaimerComponent>) {

  }
  selectTab(tab: string): void {
    this.selectedTab = tab;
  }
  onSortChange(event: any): void {
    this.sortOption = event.target.value;
  }
  onFilterChange(event: any): void {
    this.filterOption = event.target.value;
  }
  applyFilters(): void {
    this.bottomSheetRef.dismiss({ sort: this.sortOption, filter: this.filterOption });
  }
}
