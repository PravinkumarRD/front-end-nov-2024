import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { EmployeesModule } from "./employees/employees.module";
import { EventsModule } from './events/events.module';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { ButtonDemoComponent } from './components/button-demo/button-demo.component';
import { TrainBookingComponent } from './components/train-booking/train-booking.component';
import { StationSearchComponent } from './components/station-search/station-search.component';
import { DisplayBottomSheetExampleComponent } from './components/display-bottom-sheet-example/display-bottom-sheet-example.component';


@NgModule({
  declarations: [
    AppComponent,
    ButtonDemoComponent,
    TrainBookingComponent,
    StationSearchComponent,
    DisplayBottomSheetExampleComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    EmployeesModule,
    EventsModule,
    FormsModule
],
  providers: [
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
