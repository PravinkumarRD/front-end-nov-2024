import { NgModule } from '@angular/core';
import { RouterModule, Routes } from "@angular/router";

import { HomeComponent } from './home/components/home/home.component';
import { NotFoundComponent } from './shared/components/not-found/not-found.component';
import { LoginComponent } from './security/components/login/login.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    title: 'Bajaj EP Home'
  },
  {
    path: 'home',
    component: HomeComponent,
    title: 'Bajaj EP Home'
  },
  {
    path: 'employees',
    loadChildren: () => import("./employees/employees.module").then(m => m.EmployeesModule)
  },
  {
    path: 'events',
    loadChildren: () => import("./events/events.module").then(m => m.EventsModule)
  },
  {
    path:'login',
    component:LoginComponent,
    title:'Bajaj Authentication'
  },
  {
    path: '**',
    component: NotFoundComponent,
    title: 'Not Found Resource'
  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }
