import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { EventsListComponent } from './events-list.component';
import { BajajEventsService } from '../../services/bajaj-events.service';
import { Event } from '../../models/event';

describe('EventsListComponent', () => {
  let component: EventsListComponent;
  let fixture: ComponentFixture<EventsListComponent>;
  let bajajEventsServiceStub: Partial<BajajEventsService>;

  const mockEvents: Event[] = [
    { id: 1, eventCode: '9999', eventName: 'Event 1', description: 'Event-1', startDate: new Date(), endDate: new Date(), fees: 1000, seatsFilled: 100, logo: '' },
    { id: 2, eventCode: '9999', eventName: 'Event 2', description: 'Event-2', startDate: new Date(), endDate: new Date(), fees: 1000, seatsFilled: 100, logo: '' },
  ];

  beforeEach(() => {
    bajajEventsServiceStub = {
      getAllEvents: () => of(mockEvents)
    };

    TestBed.configureTestingModule({
      declarations: [ EventsListComponent ],
      providers: [
        { provide: BajajEventsService, useValue: bajajEventsServiceStub }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(EventsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize with events', () => {
    component.ngOnInit();
    expect(component.events.length).toBe(2);
    expect(component.filteredEvents.length).toBe(2);
  });

  it('should filter events based on search characters', () => {
    component.searchCharacters = 'event 1';
    component.searchEvents();
    expect(component.filteredEvents.length).toBe(1);
    expect(component.filteredEvents[0].eventName).toBe('Event 1');
  });

  it('should reset filter when search characters are cleared', () => {
    component.searchCharacters = '';
    component.searchEvents();
    expect(component.filteredEvents.length).toBe(2);
  });

  it('should unsubscribe from events service on destroy', () => {
    const unsubscribeSpy = spyOn((component as any)._eventsServiceSubscription, 'unsubscribe').and.callThrough();
    component.ngOnDestroy();
    expect(unsubscribeSpy).toHaveBeenCalled();
  });
});