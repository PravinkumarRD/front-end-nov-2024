import { Component } from '@angular/core';

@Component({
  selector: 'bajaj-button-demo',
  standalone: false,

  templateUrl: './button-demo.component.html',
  styleUrl: './button-demo.component.scss'
})
export class ButtonDemoComponent {
  buttonLabels = [30, 60, 90, 120, 'Custom'];
  showCustomInput = false;
  customValue: number;
  onButtonClick(label: number | string): void {
    if (label === 'Custom') {
      this.showCustomInput = true;
    }
    else {
      this.showCustomInput = false;
      console.log(`Button ${label} clicked!`);
      this.executeLogic(label);
    }
  }
  onCustomButtonClick(): void {
    console.log(`Custom value: ${this.customValue}`);
    this.executeLogic(this.customValue);
  }
  executeLogic(value: number | string): void { // Implement your custom logic here 
    console.log(`Executing logic for value: ${value}`);
  }
}
