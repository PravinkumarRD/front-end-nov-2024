import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MultiLingualDatePipe } from './pipes/multi-lingual-date.pipe';
import { HighlighterDirective } from './directives/highlighter.directive';



@NgModule({
  declarations: [
    MultiLingualDatePipe,
    HighlighterDirective
  ],
  imports: [
    CommonModule
  ],
  exports: [
    MultiLingualDatePipe,
    HighlighterDirective
  ]
})
export class SharedModule { }
