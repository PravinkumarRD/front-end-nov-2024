import { Component, OnInit, OnDestroy } from '@angular/core';
// import { Subscription } from "rxjs";
import { Observable } from "rxjs";

import { Employee } from "../../models/employee";

import { EMPLOYEES_LIST_TITLE, EMPLOYEES_LIST_SUB_TITLE, TABLE_COLUMNS } from "../../../statics/employee-statics";

import { BajajEmployeesService } from "../../services/bajaj-employees.service";

@Component({
  selector: 'bajaj-employees-list',
  standalone: false,
  templateUrl: './employees-list.component.html',
  styleUrl: './employees-list.component.scss'
})
export class EmployeesListComponent implements OnInit, OnDestroy {
  constructor(private _employeesService: BajajEmployeesService) {

  }

  // private _employeesServiceSubscription: Subscription;
  pageTitle: string = EMPLOYEES_LIST_TITLE;
  pageSubTitle: string = EMPLOYEES_LIST_SUB_TITLE;
  columns: string[] = TABLE_COLUMNS;
  employees: Observable<Employee[]>;
  selectedEmployee!: Employee;
  childMessage: string;

  ngOnInit(): void {
    this.employees = this._employeesService.getAllEmployees();
  }

  onEmployeeSelection(employee: Employee): void {
    this.selectedEmployee = employee;
  }
  onChildMessageReceived(message: string): void {
    this.childMessage = message;
    console.log(this.childMessage);
  }
  ngOnDestroy(): void {
    // if (this._employeesServiceSubscription)
    //   this._employeesServiceSubscription.unsubscribe();
  }
}
