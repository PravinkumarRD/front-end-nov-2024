import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

import { AuthResponse } from "../models/auth-response";
import { User } from "../models/user";

@Injectable()
export class SecurityService {

  constructor(private _httpClient: HttpClient) {

  }
  checkCredentials(user: User): Observable<AuthResponse> {
    return this._httpClient.post<AuthResponse>(`http://localhost:9090/api/users/authenticate`, user, {
      headers: {
        "Content-Type": "application/json"
      }
    });
  }
}
