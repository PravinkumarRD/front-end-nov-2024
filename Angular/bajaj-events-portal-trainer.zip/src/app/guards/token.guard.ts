import { inject } from "@angular/core";
import { CanActivateFn, Router } from '@angular/router';

export const tokenGuard: CanActivateFn = (route, state) => {
  
  let token = localStorage.getItem('token');
  if (token) {
    return true;
  } else {
    const router = inject(Router);
    router.navigate(['/login'], {
      queryParams: {
        "returnurl": state.url
      }
    });
    return false;
  }

};

///login?returnurl=/events