import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MultiLingualDatePipe } from './pipes/multi-lingual-date.pipe';
import { NotFoundComponent } from './components/not-found/not-found.component';



@NgModule({
  declarations: [
    MultiLingualDatePipe,
    NotFoundComponent
  ],
  imports: [
    CommonModule
  ],
  exports: [
    MultiLingualDatePipe,
    NotFoundComponent
  ]
})
export class SharedModule { }
