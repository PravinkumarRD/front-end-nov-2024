import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from "@angular/common/http";
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { EventsRoutingModule } from './events-routing.module';

import { EventsListComponent } from './components/events-list/events-list.component';
import { EventDetailsComponent } from './components/event-details/event-details.component';

import { SharedModule } from '../shared/shared.module';

import { BajajEventsService } from './services/bajaj-events.service';
import { RegisterEventComponent } from './components/register-event/register-event.component';



@NgModule({
  declarations: [
    EventsListComponent,
    EventDetailsComponent,
    RegisterEventComponent
  ],
  providers:[
    BajajEventsService
  ],
  imports: [
    EventsRoutingModule,
    CommonModule,
    FormsModule,
    HttpClientModule,
    SharedModule,
    ReactiveFormsModule,
    RouterModule
  ],
  exports:[
    EventsListComponent
  ]
})
export class EventsModule { }
