import { Directive, ElementRef, Renderer2, HostListener } from '@angular/core';

@Directive({
  selector: '[bajajHighlighter]',
  standalone:false
})
export class HighlighterDirective {
  constructor(private el: ElementRef, private renderer: Renderer2) {}

  @HostListener('mouseenter') onMouseEnter() {
    this.setHighlighter('skewY(-10deg) scale(1.5)', 'transform 0.5s ease-in-out');
  }

  @HostListener('mouseleave') onMouseLeave() {
    this.setHighlighter('skewY(0deg)', 'transform 0.5s ease-in-out');
  }

  private setHighlighter(transform: string, transition: string) {
    this.renderer.setStyle(this.el.nativeElement, 'transform', transform);
    this.renderer.setStyle(this.el.nativeElement, 'transition', transition);
  }
}
// import { Directive, ElementRef, Renderer2, HostListener } from '@angular/core';

// @Directive({
//   selector: '[bajajHighlighter]'
// })
// export class HighlighterDirective {
//   constructor(private el: ElementRef, private renderer: Renderer2) {}

//   @HostListener('mouseenter') onMouseEnter() {
//     this.setHighlighter('skewY(-10deg)', 'transform 0.5s ease-in-out');
//     this.createShowerEffect();
//   }

//   @HostListener('mouseleave') onMouseLeave() {
//     this.setHighlighter('skewY(0deg)', 'transform 0.5s ease-in-out');
//     this.removeShowerEffect();
//   }

//   private setHighlighter(transform: string, transition: string) {
//     this.renderer.setStyle(this.el.nativeElement, 'transform', transform);
//     this.renderer.setStyle(this.el.nativeElement, 'transition', transition);
//   }

//   private createShowerEffect() {
//     const showerContainer = this.renderer.createElement('div');
//     this.renderer.addClass(showerContainer, 'shower-container');
//     for (let i = 0; i < 30; i++) {
//       const drop = this.renderer.createElement('div');
//       this.renderer.addClass(drop, 'drop');
//       this.renderer.setStyle(drop, '--i', `${i}`);
//       this.renderer.appendChild(showerContainer, drop);
//     }
//     this.renderer.appendChild(this.el.nativeElement, showerContainer);
//   }

//   private removeShowerEffect() {
//     const showerContainer = this.el.nativeElement.querySelector('.shower-container');
//     if (showerContainer) {
//       this.renderer.removeChild(this.el.nativeElement, showerContainer);
//     }
//   }
// }

