import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";

import { User } from "../../models/user";

import { SecurityService } from "../../services/security.service";

@Component({
  selector: 'bajaj-login',
  standalone: false,

  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  constructor(private _activatedRoute: ActivatedRoute, private _securityService: SecurityService, private _router: Router) {

  }
  pageTitle: string = "Welcome To Bajaj Authentication Window!";
  user: User = new User();
  errorMessage: string;
  private _returnUrl: string;
  onCredentialsSubmit(): void {
    this._securityService.checkCredentials(this.user).subscribe({
      next: data => {
        if (!data.accessToken) {
          this.errorMessage = data.message;
        } else {
          this._returnUrl = this._activatedRoute.snapshot.queryParams['returnurl'];
          //Advice is to create a service which will read and write in local storage
          localStorage.setItem('email', data.accessToken.email);
          localStorage.setItem('role', data.accessToken.role);
          localStorage.setItem('token', data.accessToken.token);
          if (this._returnUrl) {
            this._router.navigate([this._returnUrl]);
          }
          else {
            this._router.navigate(['/home']);
          }

        }

      },
      error: err => console.log(err)
    });
    setTimeout(() => {
      this.errorMessage = '';
    }, 5000);
  }
}
