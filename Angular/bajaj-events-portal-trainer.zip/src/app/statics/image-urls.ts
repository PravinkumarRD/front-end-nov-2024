const jQueryLogo = 'assets/images/jq3.png';
const ng1Logo = 'assets/images/ng1.png';
const ng2Logo = 'assets/images/ng2.png';
const bs3Logo = 'assets/images/bs3.png';
const noImageLogo = 'assets/images/noimage.png';

export { jQueryLogo, ng1Logo, ng2Logo, bs3Logo, noImageLogo }