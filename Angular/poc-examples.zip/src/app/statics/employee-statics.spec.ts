import { EmployeeStatics } from './employee-statics';

describe('EmployeeStatics', () => {
  it('should create an instance', () => {
    expect(new EmployeeStatics()).toBeTruthy();
  });
});
