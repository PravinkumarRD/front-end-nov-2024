import { Component } from '@angular/core';

@Component({
  selector: 'bajaj-forbidden-access',
  standalone: false,
  
  templateUrl: './forbidden-access.component.html',
  styleUrl: './forbidden-access.component.scss'
})
export class ForbiddenAccessComponent {

}
