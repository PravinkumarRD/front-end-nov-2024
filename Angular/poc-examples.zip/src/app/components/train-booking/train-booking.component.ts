import { Component } from '@angular/core';

@Component({
  selector: 'bajaj-train-booking',
  standalone: false,

  templateUrl: './train-booking.component.html',
  styleUrl: './train-booking.component.scss'
})
export class TrainBookingComponent {
  fromCity: string = '';
  toCity: string = '';
  showSearch: boolean = false;
  currentTarget: string = '';
  showError: boolean = false;
  openCitySearch(target: string): void {
    this.currentTarget = target;
    this.showSearch = true;
  } 
  setCity(city: string): void {
    this.showError = false; // Reset the error message 
    if (this.currentTarget === 'from') {
      this.fromCity = city;
    } else if (this.currentTarget === 'to') {
      this.toCity = city;
    }
    this.validateCities();
    this.showSearch = false;
  }
  hideSearch(): void {
    this.showSearch = false;
  }
  swapCities(): void {
    const temp = this.fromCity;
    this.fromCity = this.toCity;
    this.toCity = temp;
    this.validateCities();
  }
  validateCities(): void {
    if (this.fromCity && this.toCity && this.fromCity === this.toCity) {
      this.showError = true;
    }
    else {
      this.showError = false;
    }
  }
}
