import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'multiLingualDate',
  standalone: false
})
export class MultiLingualDatePipe implements PipeTransform {
  transform(value: Date, ...args: string[]): string {
    if (!value) return "";
    let locale: string = args[0] ? args[0] : 'en-IN';
    return new Intl.DateTimeFormat(locale, {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    }).format(new Date(value));
  }
}
